from project.fruit import Fruit


product = Fruit("Banana", "12.03.2023")
print(product.name)
print(product.expiration_date)
