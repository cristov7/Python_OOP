from project.dog import Dog


dog = Dog()
print(dog.eat())
print(dog.bark())
